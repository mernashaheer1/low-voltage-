/* Throttle reading, 12-bit ADC, STM32 HAL.
 * Sensor 0.5-4.5 V goes through a 12k/22k divider (x0.647) to stay under 3.3 V,
 * so counts = about 803 x sensor volts. ADC runs with DMA into buf[].
 * A weak pull-down makes an unplugged sensor read 0 V. */
#include "main.h"

#define N         16
#define RAW_MIN   402      /* 0.5 V = 0 %   */
#define RAW_MAX   3614     /* 4.5 V = 100 % */
#define RAW_LOW   200      /* below: open circuit or short to GND (0.25 V) */
#define RAW_HIGH  3814     /* above: short to 5 V (4.75 V) */
#define TOL       20

extern ADC_HandleTypeDef hadc1;
static uint16_t buf[N];
static int filt = RAW_MIN, out = 0, bad = 0, good = 0, fault = 0;
int thr_fault_code = 0;    /* 0 ok, 1 open/short GND, 2 short to 5 V, 3 out of range */

void Throttle_Init(void) { HAL_ADC_Start_DMA(&hadc1, (uint32_t *)buf, N); }

/* call every 10 ms, returns throttle in 0.1 % (0..1000) */
int Throttle_Task(void)
{
    uint32_t sum = 0;
    for (int i = 0; i < N; i++) sum += buf[i];
    int raw = sum / N;                                   /* average */

    int code = 0;
    if (raw < RAW_LOW) code = 1;
    else if (raw > RAW_HIGH) code = 2;
    else if (raw < RAW_MIN - TOL || raw > RAW_MAX + TOL) code = 3;

    if (code) { good = 0; if (bad < 3) bad++; if (bad >= 3) { fault = 1; thr_fault_code = code; } }
    else {
        bad = 0; if (good < 50) good++;
        if (fault && good >= 50 && raw < RAW_MIN + 160) { fault = 0; thr_fault_code = 0; } /* pedal released */
    }
    if (fault) { out = 0; filt = raw; return 0; }       /* invalid signal: zero torque */
    if (code) return out;                                /* glitch shorter than 30 ms: hold */

    filt += (raw - filt) / 4;                            /* low-pass filter */
    int t = (filt - RAW_MIN) * 1000 / (RAW_MAX - RAW_MIN);
    if (t < 0) t = 0;
    if (t > 1000) t = 1000;

    if (t > out + 20) out += 20;                         /* rise max 2 % per 10 ms */
    else if (t < out - 50) out -= 50;                    /* fall max 5 % per 10 ms */
    else out = t;
    return out;
}
