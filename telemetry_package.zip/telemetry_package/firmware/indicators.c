/* Indicators + hazard, STM32 HAL, no blocking delays.
 * TIM3 is set to 3 Hz (72 MHz clock, PSC = 7199, ARR = 3332), so the lamp
 * state flips every 333 ms = 1.5 Hz blink. */
#include "main.h"

#define DEBOUNCE_MS 30

enum { OFF, LEFT, RIGHT, HAZARD };
static int mode = OFF;
static volatile uint8_t blink = 0;          /* flipped by the TIM3 interrupt */
extern TIM_HandleTypeDef htim3;

typedef struct { GPIO_TypeDef *port; uint16_t pin; uint8_t last, stable; uint32_t t; } Btn;
static Btn bL = { BTN_LEFT_GPIO_Port,  BTN_LEFT_Pin  };
static Btn bR = { BTN_RIGHT_GPIO_Port, BTN_RIGHT_Pin };
static Btn bH = { BTN_HAZ_GPIO_Port,   BTN_HAZ_Pin   };

/* returns 1 once per press, only after the level was stable for 30 ms */
static int pressed(Btn *b)
{
    uint8_t raw = (HAL_GPIO_ReadPin(b->port, b->pin) == GPIO_PIN_RESET); /* pull-up, pressed = low */
    if (raw != b->last) { b->last = raw; b->t = HAL_GetTick(); }
    if (raw != b->stable && (HAL_GetTick() - b->t) >= DEBOUNCE_MS) {
        b->stable = raw;
        return raw;                          /* ignore the release */
    }
    return 0;
}

static void restart_blink(void)
{
    __HAL_TIM_SET_COUNTER(&htim3, 0);
    blink = 1;                               /* lamp turns on right away */
}

void Indicators_Init(void) { HAL_TIM_Base_Start_IT(&htim3); }

void Indicators_Task(void)                   /* call in the main loop, never blocks */
{
    if (pressed(&bH)) { mode = (mode == HAZARD) ? OFF : HAZARD; restart_blink(); }
    if (pressed(&bL) && mode != HAZARD) { mode = (mode == LEFT)  ? OFF : LEFT;  restart_blink(); }
    if (pressed(&bR) && mode != HAZARD) { mode = (mode == RIGHT) ? OFF : RIGHT; restart_blink(); }

    uint8_t l = blink && (mode == LEFT  || mode == HAZARD);
    uint8_t r = blink && (mode == RIGHT || mode == HAZARD);
    HAL_GPIO_WritePin(LAMP_LEFT_GPIO_Port,  LAMP_LEFT_Pin,  l ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LAMP_RIGHT_GPIO_Port, LAMP_RIGHT_Pin, r ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM3) blink ^= 1;
}
